package nl.inholland.javafx.models;

public enum ComponentEnum {
    AddShowingForm, AddTicketForm, showMainWindow, ManageMovies
}
