package nl.inholland.javafx.models.login;

public enum UserType {
    User,
    Admin
}
