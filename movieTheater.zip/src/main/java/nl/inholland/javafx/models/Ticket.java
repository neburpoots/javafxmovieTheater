package nl.inholland.javafx.models;

public class Ticket {
    private String name;

    public Ticket(String name) {
        this.name = name;
    }

    public String getName() {
        return name;
    }
}
